#ifndef _STATUS_H_
#define _STATIS_H_

#include <stdio.h>

int status_init();

int get_status(int ch);



#endif //_STATUS_H_

